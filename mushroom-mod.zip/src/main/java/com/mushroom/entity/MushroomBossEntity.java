package com.mushroom.entity;

import com.mushroom.ModEntities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.PlayState;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Грибной король (босс). Призывается Грибным сердцем.
 * - Удар: споровый удар по области 4 блока с замедлением.
 * - Каждые 15 сек рычит и призывает двух жуков.
 * - Ниже 50% HP — ярость: сила и скорость.
 * Дроп: Ядро гриба 1-2, Споровый кристалл 3-5 (loot_tables).
 */
public class MushroomBossEntity extends HostileEntity implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bossBar = new ServerBossBar(this.getDisplayName(),
            BossBar.Color.GREEN, BossBar.Style.PROGRESS);
    private boolean enraged = false;

    public MushroomBossEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 50;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 200.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0)
                .add(EntityAttributes.GENERIC_ARMOR, 10.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.7));
        this.goalSelector.add(3, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (!(this.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }
        // Полоска HP видна игрокам рядом
        bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        for (ServerPlayerEntity player : serverWorld.getPlayers()) {
            if (player.squaredDistanceTo(this) < 40.0 * 40.0) {
                bossBar.addPlayer(player);
            }
        }
        // Ярость ниже половины здоровья
        if (!enraged && this.getHealth() < this.getMaxHealth() / 2.0F) {
            enraged = true;
            this.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 60, 1));
            this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 60, 1));
            this.playAnim("enrage");
        }
        // Рёв и призыв жуков раз в 15 сек во время боя
        if (this.getTarget() != null && this.age % 300 == 0) {
            this.playAnim("spore_roar");
            for (int i = 0; i < 2; i++) {
                BeetleEntity beetle = ModEntities.BEETLE.create(serverWorld);
                if (beetle != null) {
                    beetle.refreshPositionAndAngles(this.getX() + (i == 0 ? -3 : 3), this.getY(),
                            this.getZ(), this.getYaw(), 0.0F);
                    serverWorld.spawnEntity(beetle);
                }
            }
        }
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (!this.getWorld().isClient) {
            this.playAnim("attack_slam");
            // Споровый удар: всем рядом замедление
            for (LivingEntity near : this.getWorld().getEntitiesByClass(LivingEntity.class,
                    this.getBoundingBox().expand(4.0), e -> e != this)) {
                near.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
            }
        }
        return hit;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean result = super.damage(source, amount);
        if (result && this.isAlive() && !this.getWorld().isClient) {
            this.playAnim("hurt");
        }
        return result;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        bossBar.clearPlayers();
    }

    private void playAnim(String name) {
        this.cache.getManagerForId(this.getId()).tryTriggerAnimation(name);
    }

    // ---------- GeckoLib анимации ----------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 5, this::predicate)
                .triggerableAnim("attack_slam", RawAnimation.begin().thenPlay("attack_slam"))
                .triggerableAnim("spore_roar", RawAnimation.begin().thenPlay("spore_roar"))
                .triggerableAnim("hurt", RawAnimation.begin().thenPlay("hurt"))
                .triggerableAnim("enrage", RawAnimation.begin().thenPlay("enrage")));
    }

    private PlayState predicate(AnimationState<MushroomBossEntity> state) {
        if (this.isDead()) {
            return state.setAndContinue(RawAnimation.begin().thenPlayAndHold("death"));
        }
        if (state.isMoving()) {
            return state.setAndContinue(RawAnimation.begin().thenLoop("walk"));
        }
        return state.setAndContinue(RawAnimation.begin().thenLoop("idle"));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
