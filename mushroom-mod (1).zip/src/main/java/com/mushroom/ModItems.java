package com.mushroom;

import com.mushroom.item.MushroomSwordItem;
import com.mushroom.item.SummonItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item MUSHROOM_CORE = register("mushroom_core", new Item(new FabricItemSettings()));
    public static final Item SPORE_CRYSTAL = register("spore_crystal", new Item(new FabricItemSettings()));
    public static final Item BEETLE_SHELL = register("beetle_shell", new Item(new FabricItemSettings()));
    public static final Item MUSHROOM_HEART = register("mushroom_heart",
            new SummonItem(new FabricItemSettings().maxCount(1)));
    public static final Item MUSHROOM_SWORD = register("mushroom_sword",
            new MushroomSwordItem(new FabricItemSettings()));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(MushroomMod.MOD_ID, name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(MUSHROOM_CORE);
            entries.add(SPORE_CRYSTAL);
            entries.add(BEETLE_SHELL);
            entries.add(MUSHROOM_HEART);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(MUSHROOM_SWORD));
    }
}
