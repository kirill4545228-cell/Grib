package com.mushroom;

import com.mushroom.entity.BeetleEntity;
import com.mushroom.entity.MushroomBossEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

public class ModEntities {
    public static final EntityType<BeetleEntity> BEETLE = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MushroomMod.MOD_ID, "beetle"),
            FabricEntityTypeBuilder.createMob().spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(BeetleEntity::new)
                    .dimensions(EntityDimensions.fixed(1.2F, 0.9F)).build());

    public static final EntityType<MushroomBossEntity> MUSHROOM_BOSS = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MushroomMod.MOD_ID, "mushroom_boss"),
            FabricEntityTypeBuilder.createMob().spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(MushroomBossEntity::new)
                    .dimensions(EntityDimensions.fixed(2.5F, 4.0F)).fireImmune().build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(BEETLE, BeetleEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MUSHROOM_BOSS, MushroomBossEntity.createAttributes());
        SpawnRestriction.register(BEETLE, SpawnRestriction.Location.NO_RESTRICTIONS,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
    }
}
