package com.mushroom;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.entity.SpawnGroup;

public class MushroomMod implements ModInitializer {
    public static final String MOD_ID = "mushroom";

    @Override
    public void onInitialize() {
        ModItems.register();
        ModEntities.register();
        // Жуки появляются в обычном мире (поверхность и пещеры по биому), 1-2 штуки в группе
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER,
                ModEntities.BEETLE, 20, 1, 2);
    }
}
