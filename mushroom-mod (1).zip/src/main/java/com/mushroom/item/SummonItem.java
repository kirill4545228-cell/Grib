package com.mushroom.item;

import com.mushroom.ModEntities;
import com.mushroom.entity.MushroomBossEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Грибное сердце: ПКМ по блоку призывает Грибного короля и тратится. */
public class SummonItem extends Item {
    public SummonItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (!world.isClient) {
            MushroomBossEntity boss = ModEntities.MUSHROOM_BOSS.create(world);
            if (boss != null) {
                BlockPos pos = context.getBlockPos().up();
                boss.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5,
                        context.getPlayerYaw(), 0.0F);
                world.spawnEntity(boss);
                PlayerEntity player = context.getPlayer();
                if (player == null || !player.isCreative()) {
                    context.getStack().decrement(1);
                }
            }
        }
        return ActionResult.SUCCESS;
    }
}
