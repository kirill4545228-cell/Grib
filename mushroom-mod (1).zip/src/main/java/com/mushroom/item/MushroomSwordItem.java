package com.mushroom.item;

import com.mushroom.ModItems;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.Ingredient;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

/**
 * Грибной меч.
 * - Удар: отравление на 3 сек.
 * - ПКМ: споровый взрыв по радиусу 4 блока: 5 урона и замедление (перезарядка 10 сек).
 */
public class MushroomSwordItem extends SwordItem {
    private static final int ABILITY_COOLDOWN = 200; // тики (10 сек)
    private static final float BLAST_RADIUS = 4.0F;
    private static final float BLAST_DAMAGE = 5.0F;

    private static final ToolMaterial MATERIAL = new ToolMaterial() {
        @Override public int getDurability() { return 1200; }
        @Override public float getMiningSpeedMultiplier() { return 7.0F; }
        @Override public float getAttackDamage() { return 3.0F; }
        @Override public int getMiningLevel() { return 2; }
        @Override public int getEnchantability() { return 15; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.MUSHROOM_CORE); }
    };

    public MushroomSwordItem(Item.Settings settings) {
        super(MATERIAL, 4, -2.4F, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 60, 0));
        return super.postHit(stack, target, attacker);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        if (!world.isClient) {
            Box area = user.getBoundingBox().expand(BLAST_RADIUS);
            for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, area,
                    e -> e != user && e.isAlive())) {
                target.damage(DamageSource.player(user), BLAST_DAMAGE);
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 2));
            }
            if (world instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR,
                        user.getX(), user.getBodyY(0.5), user.getZ(), 60, 2.5, 1.0, 2.5, 0.05);
            }
            user.getItemCooldownManager().set(this, ABILITY_COOLDOWN);
            stack.damage(1, user, p -> p.sendToolBreakStatus(hand));
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
