package com.mushroom.client;

import com.mushroom.ModEntities;
import com.mushroom.MushroomMod;
import com.mushroom.entity.BeetleEntity;
import com.mushroom.entity.MushroomBossEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class MushroomModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.BEETLE, BeetleRenderer::new);
        EntityRendererRegistry.register(ModEntities.MUSHROOM_BOSS, BossRenderer::new);
    }

    /** Модель: assets/mushroom/geo/beetle.geo.json, animations/beetle.animation.json, textures/entity/beetle.png */
    public static class BeetleRenderer extends GeoEntityRenderer<BeetleEntity> {
        public BeetleRenderer(EntityRendererFactory.Context ctx) {
            super(ctx, new DefaultedEntityGeoModel<BeetleEntity>(new Identifier(MushroomMod.MOD_ID, "beetle")));
            this.shadowRadius = 0.3F;
        }
    }

    /** Модель: assets/mushroom/geo/boss.geo.json, animations/boss.animation.json, textures/entity/boss.png */
    public static class BossRenderer extends GeoEntityRenderer<MushroomBossEntity> {
        public BossRenderer(EntityRendererFactory.Context ctx) {
            super(ctx, new DefaultedEntityGeoModel<MushroomBossEntity>(new Identifier(MushroomMod.MOD_ID, "boss")));
            this.shadowRadius = 1.2F;
        }
    }
}
